#ifndef EXPR_H
#define EXPR_H

#include <string>

// Base expression class
class Expr {
public:
    virtual bool equals(Expr* e) = 0;
};

// Numeric expression
class NumExpr : public Expr {
public:
    int val;  // Stores the numeric value
    NumExpr(int val);  // Constructor
    bool equals(Expr* e);
};

// Variable expression
class VarExpr : public Expr {
public:
    std::string name;  // Stores the variable name
    VarExpr(std::string name);  // Constructor
    bool equals(Expr* e);
};

// Addition expression - newly added
class AddExpr : public Expr {
public:
    Expr* lhs;  // Left operand
    Expr* rhs;  // Right operand
    AddExpr(Expr* lhs, Expr* rhs);  // Constructor
    bool equals(Expr* e);
};

#endif



//定義了一個抽象基類 Expr 和三個子類別：NumExpr（數字表達式）、VarExpr（變數表達式）、AddExpr（加法表達式），用於表示數學表達式的結構。每個子類別實作了 equals 方法，用於比較表達式是否相等
