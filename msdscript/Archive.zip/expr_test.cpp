#define CATCH_CONFIG_MAIN
#include <catch2/catch_all.hpp>
#include "expr.h"

TEST_CASE("test equal") {
    // test number
    CHECK((new NumExpr(5))->equals(new NumExpr(5)) == true);
    CHECK((new NumExpr(5))->equals(new NumExpr(10)) == false);

    // test add
    CHECK((new AddExpr(new NumExpr(1), new NumExpr(2)))
          ->equals(new AddExpr(new NumExpr(1), new NumExpr(2))) == true);

    // test var
    CHECK((new VarExpr("x"))->equals(new VarExpr("x")) == true);
    CHECK((new VarExpr("x"))->equals(new VarExpr("y")) == false);
}

