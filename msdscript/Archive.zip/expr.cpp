#include "expr.h"

// Implementation of numeric expression
NumExpr::NumExpr(int val) {
    this->val = val;
}

bool NumExpr::equals(Expr* e) {
    // Check if it is a numeric expression
    NumExpr* n = dynamic_cast<NumExpr*>(e);
    if(n == nullptr) {
        return false;  // Not a numeric expression
    }
    return this->val == n->val;  // Compare values
}

// Implementation of variable expression
VarExpr::VarExpr(std::string name) {
    this->name = name;
}

bool VarExpr::equals(Expr* e) {
    // Check if it is a variable expression
    VarExpr* v = dynamic_cast<VarExpr*>(e);
    if(v == nullptr) {
        return false;  // Not a variable expression
    }
    return this->name == v->name;  // Compare variable names
}

// Implementation of addition expression
AddExpr::AddExpr(Expr* lhs, Expr* rhs) {
    this->lhs = lhs;
    this->rhs = rhs;
}

bool AddExpr::equals(Expr* e) {
    // Check if it is an addition expression
    AddExpr* a = dynamic_cast<AddExpr*>(e);
    if(a == nullptr) {
        return false;  // Not an addition expression
    }
    // Compare the left and right expressions
    return this->lhs->equals(a->lhs) && this->rhs->equals(a->rhs);
}
