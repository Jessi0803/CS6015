#include "expr.h"

// Implementation of numeric expression
NumExpr::NumExpr(int val) {
    this->val = val;
}

bool NumExpr::equals(Expr* e) {
    NumExpr* n = dynamic_cast<NumExpr*>(e);
    if(n == nullptr) {
        return false;
    }
    return this->val == n->val;
}

int NumExpr::interp() {
    return val;  // Return the numeric value
}

bool NumExpr::has_variable() {
    return false;  // Numbers don't contain variables
}

Expr* NumExpr::subst(std::string var, Expr* replacement) {
    return new NumExpr(val);  // Numbers remain unchanged
}

// Implementation of variable expression
VarExpr::VarExpr(std::string name) {
    this->name = name;
}

bool VarExpr::equals(Expr* e) {
    VarExpr* v = dynamic_cast<VarExpr*>(e);
    if(v == nullptr) {
        return false;
    }
    return this->name == v->name;
}

int VarExpr::interp() {
    throw std::runtime_error("no value for variable");  // Variables can't be evaluated
}

bool VarExpr::has_variable() {
    return true;  // Variables are variables
}

Expr* VarExpr::subst(std::string var, Expr* replacement) {
    if (this->name == var) {
        return replacement;  // Replace if names match
    }
    return new VarExpr(this->name);  // Otherwise return copy
}

// Implementation of addition expression
AddExpr::AddExpr(Expr* lhs, Expr* rhs) {
    this->lhs = lhs;
    this->rhs = rhs;
}

bool AddExpr::equals(Expr* e) {
    AddExpr* a = dynamic_cast<AddExpr*>(e);
    if(a == nullptr) {
        return false;
    }
    return this->lhs->equals(a->lhs) && this->rhs->equals(a->rhs);
}

int AddExpr::interp() {
    return lhs->interp() + rhs->interp();  // Add the values
}

bool AddExpr::has_variable() {
    return lhs->has_variable() || rhs->has_variable();  // Check both sides
}

Expr* AddExpr::subst(std::string var, Expr* replacement) {
    return new AddExpr(
        lhs->subst(var, replacement),
        rhs->subst(var, replacement)
    );  // Substitute in both subexpressions
}

// Implementation of multiplication expression
MultExpr::MultExpr(Expr* lhs, Expr* rhs) {
    this->lhs = lhs;
    this->rhs = rhs;
}

bool MultExpr::equals(Expr* e) {
    MultExpr* m = dynamic_cast<MultExpr*>(e);
    if(m == nullptr) {
        return false;
    }
    return this->lhs->equals(m->lhs) && this->rhs->equals(m->rhs);
}

int MultExpr::interp() {
    return lhs->interp() * rhs->interp();  // Multiply the values
}

bool MultExpr::has_variable() {
    return lhs->has_variable() || rhs->has_variable();  // Check both sides
}

Expr* MultExpr::subst(std::string var, Expr* replacement) {
    return new MultExpr(
        lhs->subst(var, replacement),
        rhs->subst(var, replacement)
    );  // Substitute in both subexpressions
}
