#include "expr.h"

// Implementation of numeric expression
NumExpr::NumExpr(int val) {
    this->val = val;
}

bool NumExpr::equals(Expr* e) {
    NumExpr* n = dynamic_cast<NumExpr*>(e);
    if(n == nullptr) {
        return false;
    }
    return this->val == n->val;
}

// Implementation of variable expression
VarExpr::VarExpr(std::string name) {
    this->name = name;
}

bool VarExpr::equals(Expr* e) {
    VarExpr* v = dynamic_cast<VarExpr*>(e);
    if(v == nullptr) {
        return false;
    }
    return this->name == v->name;
}

// Implementation of addition expression
AddExpr::AddExpr(Expr* lhs, Expr* rhs) {
    this->lhs = lhs;
    this->rhs = rhs;
}

bool AddExpr::equals(Expr* e) {
    AddExpr* a = dynamic_cast<AddExpr*>(e);
    if(a == nullptr) {
        return false;
    }
    return this->lhs->equals(a->lhs) && this->rhs->equals(a->rhs);
}

// Implementation of multiplication expression (NEW)
MultExpr::MultExpr(Expr* lhs, Expr* rhs) {
    this->lhs = lhs;
    this->rhs = rhs;
}

bool MultExpr::equals(Expr* e) {
    MultExpr* m = dynamic_cast<MultExpr*>(e);
    if(m == nullptr) {
        return false;
    }
    return this->lhs->equals(m->lhs) && this->rhs->equals(m->rhs);
}

