//
//  Untitled.h
//  Project Phase 1
//
//  Created by Jessi on 1/13/25.
//

#ifndef CMDLINE_H
#define CMDLINE_H

// Declare a function to handle command line parameters
void use_arguments(int argc, char** argv);

#endif
