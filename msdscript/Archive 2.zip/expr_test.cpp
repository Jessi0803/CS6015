#define CATCH_CONFIG_MAIN
#include <catch2/catch_all.hpp>
#include "expr.h"

TEST_CASE("test equals") {
    // Test number
    CHECK((new NumExpr(5))->equals(new NumExpr(5)) == true);
    CHECK((new NumExpr(5))->equals(new NumExpr(10)) == false);

    // Test variable
    CHECK((new VarExpr("x"))->equals(new VarExpr("x")) == true);
    CHECK((new VarExpr("x"))->equals(new VarExpr("y")) == false);
    CHECK((new NumExpr(1))->equals(new VarExpr("x")) == false);

    // Test addition
    CHECK((new AddExpr(new NumExpr(2), new NumExpr(3)))->equals(new AddExpr(new NumExpr(2), new NumExpr(3))) == true);
    CHECK((new AddExpr(new NumExpr(2), new NumExpr(3)))->equals(new AddExpr(new NumExpr(3), new NumExpr(2))) == false);
    CHECK((new AddExpr(new NumExpr(2), new NumExpr(3)))->equals(new AddExpr(new NumExpr(2), new NumExpr(4))) == false);

    // Test multiplication
    CHECK((new MultExpr(new NumExpr(2), new NumExpr(3)))->equals(new MultExpr(new NumExpr(2), new NumExpr(3))) == true);
    CHECK((new MultExpr(new NumExpr(2), new NumExpr(3)))->equals(new MultExpr(new NumExpr(3), new NumExpr(2))) == false);
    CHECK((new MultExpr(new NumExpr(2), new NumExpr(3)))->equals(new MultExpr(new NumExpr(2), new NumExpr(4))) == false);

    // Test combination of expressions
    CHECK((new AddExpr(new NumExpr(1), new MultExpr(new NumExpr(2), new NumExpr(3))))
          ->equals(new AddExpr(new NumExpr(1), new MultExpr(new NumExpr(2), new NumExpr(3)))) == true);

    CHECK((new MultExpr(new AddExpr(new NumExpr(1), new NumExpr(2)), new NumExpr(3)))
          ->equals(new MultExpr(new AddExpr(new NumExpr(1), new NumExpr(2)), new NumExpr(3))) == true);

    CHECK((new AddExpr(new NumExpr(1), new MultExpr(new NumExpr(2), new NumExpr(3))))
          ->equals(new MultExpr(new AddExpr(new NumExpr(1), new NumExpr(2)), new NumExpr(3))) == false);
}


