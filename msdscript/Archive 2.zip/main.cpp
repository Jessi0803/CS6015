//
//  main.cpp
//  Project Phase 1
//
//  Created by Jessi on 1/13/25.
//

#include <iostream>
#include "cmdline.h"

int main(int argc, char** argv) {
    use_arguments(argc, argv);  //from cmdline.cpp
    return 0;  //0 -> success
}
